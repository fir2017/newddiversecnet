﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace rolldice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string dice1;
        public string dice2;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void calculatethedice(ref string s1, ref string s2)
        {
            Random ran = new Random();
            s1 = ran.Next(1, 7).ToString();
            s2 = ran.Next(1, 7).ToString();
        }
        public void writevaluestotextbox(string dice1, string dice2)
        {
            textBox1.Text = dice1 + " : " + dice2;
            textBox2.Text += textBox1.Text + "\t\n";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            calculatethedice(ref dice1,ref dice2);
            writevaluestotextbox(dice1, dice2);
            
        }
    }
}
