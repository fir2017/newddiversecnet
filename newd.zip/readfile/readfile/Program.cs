﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace readfile
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            FileStream fin;
            if (args.Length != 1)
            {
                Console.WriteLine("Usage: ShowFile File");
                return;
            }
            try
            {
                fin = new FileStream(args[0], FileMode.Open);
            }
            catch (IOException exc)
            {
                Console.WriteLine("Cannot Open File");
                Console.WriteLine(exc.Message);
                return;
            }
            // Read bytes until EOF is encountered.
            do
            {
                try
                {
                    i = fin.ReadByte();
                }
                catch (IOException exc)
                {
                    Console.WriteLine("Error Reading File");
                    Console.WriteLine(exc.Message);
                    break;
                }
                if (i != -1) Console.Write((char)i);
            } while (i != -1);
            fin.Close();
        }
    }
}