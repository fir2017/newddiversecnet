﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace fileops
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fin;
try {
fin = new FileStream("test", FileMode.Open);
}
catch(IOException exc) { // catch all I/O exceptions
Console.WriteLine(exc.Message);
// Handle the error.
}
catch(Exception exc ){ // catch any other exception.
Console.WriteLine(exc.Message);
// Handle the error.
}

        }
    }
}
